# Design System Specification: High-End Financial Intelligence

## 1. Overview & Creative North Star
**Creative North Star: "The Luminescent Terminal"**

This design system rejects the "SaaS-template" aesthetic in favor of a bespoke, editorial experience. It merges the high-density utility of a Bloomberg Terminal with the fluid, premium grace of Stripe. We are not just displaying data; we are curating financial intelligence. 

The system moves beyond standard grids by using **intentional asymmetry** and **tonal depth**. Large, high-contrast typography scales are paired with whisper-quiet backgrounds to create an environment that feels both authoritative and ethereal. By layering translucent surfaces rather than drawing rigid boxes, we achieve a UI that breathes, guiding the eye through complex datasets without visual fatigue.

---

## 2. Colors & Surface Logic

### The "No-Line" Rule
Standard 1px solid borders are strictly prohibited for sectioning. Boundaries must be defined solely through background color shifts. For example, a `surface-container-low` section sitting on a `surface` background provides all the separation the eye needs.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of frosted glass.
- **Base Level:** `surface` (#0a0e14) — The canvas.
- **Section Level:** `surface-container-low` (#0f141a) — For secondary content areas.
- **Card Level:** `surface-container` (#151a21) — The primary container for data.
- **Floating/Active Level:** `surface-container-highest` (#20262f) — For modals, dropdowns, or hovered states.

### The "Glass & Gradient" Rule
To achieve a "signature" feel, floating elements must utilize **Glassmorphism**.
- **Formula:** Background: `rgba(255, 255, 255, 0.05)` | Backdrop Blur: `12px` to `20px`.
- **Gradients:** Use a subtle linear gradient (Top-Left to Bottom-Right) transitioning from `primary` (#49f4c8) to `primary-container` (#00d4aa) for main CTAs. This adds a "soul" to the UI that flat hex codes cannot replicate.

---

## 3. Typography
We use **Inter** for its mathematical precision. The hierarchy is designed to be "Editorial"—extreme contrast between massive displays and tiny, ultra-legible labels.

| Token | Size | Weight | Use Case |
| :--- | :--- | :--- | :--- |
| **display-lg** | 3.5rem | 700 | Hero portfolio balances / High-impact figures. |
| **headline-sm** | 1.5rem | 600 | Page headers and section titles. |
| **title-sm** | 1rem | 500 | Card titles and prominent data points. |
| **body-md** | 0.875rem | 400 | Primary reading text (The standard 14px base). |
| **label-md** | 0.75rem | 500 | Secondary data descriptors / Small caps / Metadata. |

**Editorial Note:** Always pair `label-md` in `on-surface-variant` (#a8abb3) with `title-sm` in `on-surface` (#f1f3fc) to create a clear informational hierarchy.

---

## 4. Elevation & Depth

### The Layering Principle
Depth is achieved through **Tonal Layering** rather than shadows.
- Place a `surface-container-lowest` card on a `surface-container-low` section to create a soft, natural "recessed" look.
- Use `spacing-4` (0.9rem) between these layers to let the background breathe.

### Ambient Shadows
Shadows are a fallback for high-elevation components (Modals/Popovers).
- **Spec:** Blur: `40px` | Opacity: `8%` | Color: `#000000`. 
- Shadows must be tinted with a hint of the background color to feel integrated, never "dirty" grey.

### The "Ghost Border" Fallback
If a border is required for accessibility, use a **Ghost Border**:
- `outline-variant` (#44484f) at **20% opacity**.
- 100% opaque borders are considered a "system failure" in this aesthetic.

---

## 5. Components

### Buttons
- **Primary:** Gradient from `primary` to `primary-container`. `radius-md`. No border. White or `on-primary` text.
- **Secondary:** Surface-container background with a `ghost border`.
- **Tertiary:** Text-only in `primary` color. Use for low-emphasis actions like "Cancel" or "Learn More."

### Input Fields
- **Container:** `surface-container-low` with a bottom-only `ghost border` (1px).
- **Focus State:** Border transitions to 100% `primary` (#49f4c8) with a soft glow (4px spread).
- **Labels:** Always use `label-sm` positioned 0.4rem above the input.

### Data Visualization (Charts)
- **Stroke:** `primary` (#49f4c8) for positive trends; `error` (#ff716c) for negative.
- **Grid Lines:** `outline-variant` at 10% opacity.
- **Area Fill:** Linear gradient from `primary` (20% opacity) to transparent.

### Cards & Lists
- **Prohibition:** Divider lines are forbidden.
- **Alternative:** Use `spacing-3` (0.6rem) of vertical whitespace or a subtle background shift to `surface-container-highest` on hover to define list items.
- **Currency:** Indian Rupees (₹) should use `font-weight: 400` even when the value is `700` to maintain elegance.

---

## 6. Do’s and Don’ts

### Do
- **Use Negative Space:** If in doubt, add `spacing-8` (1.75rem). The UI should feel expansive, like a luxury gallery.
- **Subtle Motion:** Use 200ms "Ease-Out" transitions for all hover states and glassmorphism reveals.
- **Precision:** Ensure all data is aligned to the pixel-perfect `spacing-px` grid.

### Don’t
- **Don't use pure white:** It creates "eye-bleed" on dark backgrounds. Use `on-surface` (#f1f3fc).
- **Don't use heavy shadows:** They look dated. Let color shifts handle the hierarchy.
- **Don't crowd the Navbar:** Keep the 64px sticky navbar minimal. Use `surface-bright` with 80% opacity and a `backdrop-filter`.

### Accessibility Note
While we prioritize aesthetics, ensure all `label-md` text maintain a contrast ratio of at least 4.5:1 against their respective surface containers. Use `on-surface-variant` for non-critical metadata and `on-surface` for all actionable or primary data.